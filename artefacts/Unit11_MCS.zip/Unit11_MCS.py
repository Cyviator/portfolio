# ================================
# Monte Carlo simulation method to model the likelihood of risks
# affecting product quality and supply chain availability.
#
# Optimised for Python version 3.13
# Created by: Miriam Mahabiersing
# ================================

import sys
import numpy as np
import pandas as pd
import matplotlib.pyplot as plt
from scipy import stats
from pathlib import Path
from textwrap import wrap
from datetime import datetime


try:
    sys.stdout.reconfigure(encoding="utf-8")
except Exception:
    pass

# ================================
# CONFIGURATION SET-UP
# ================================

# Number of samples per variable
n_simulations = 10_000

# Uniform bounds for each variable (as probabilities in [0, 1])
pors_bounds = (0.82, 0.95)  # Perfect Order Rate – Supplier
porw_bounds = (0.92, 0.98)  # Perfect Order Rate – Automated Warehouse
td_bounds   = (0.03, 0.07)  # Transport delay probability
qd_bounds   = (0.05, 0.10)  # Quality degradation probability

# Target for mean performance
target_mean = 0.82

# Output folder for plots/files
output_dir = Path("1_MCS-ASSIGNMENT 2")

# Global pandas display so nothing is truncated in console
pd.set_option("display.width", 200)
pd.set_option("display.max_columns", None)
pd.set_option("display.max_rows", None)
pd.set_option("display.max_colwidth", None)
pd.set_option("display.expand_frame_repr", False)
pd.set_option("display.float_format", lambda x: f"{x:0.4f}")


# ================================
# MONTE CARLO CLASS
# ================================
class MonteCarloMCS:
    def __init__(
        self,
        n_simulations: int,
        bounds: dict[str, tuple[float, float]],
        target_mean: float,
        output_dir: Path | str,
    ) -> None:
        self.n = n_simulations
        self.bounds = bounds
        self.target_mean = target_mean
        self.output_dir = Path(output_dir)
        self.output_dir.mkdir(parents=True, exist_ok=True)

        # Aliases for compact tables/prints
        self.aliases = {
            "Perfect Order Rate - Supplier": "PORS",
            "Perfect Order Rate - Automated Warehouse": "PORW",
            "Transport delay": "TD",
            "Quality degradation": "QD",
        }

        # RNG
        self.rng = np.random.default_rng()

        # Placeholders for sampled data
        self.samples: dict[str, np.ndarray] = {}
        self.performance: np.ndarray | None = None

    # ---------- Utility: banner ----------
    @staticmethod
    def _banner(title: str, body: str | None = None) -> None:
        print("\n" + "=" * 30)
        print(title)
        print("=" * 30)
        if body:
            print(body)

    # ---------- Utility: table -> PNG/CSV/MD ----------
    def _save_df_png(self, df: pd.DataFrame, title: str, filename: str) -> None:
        fig, ax = plt.subplots(figsize=(10, 0.6 + 0.5 * (len(df) + 2)))
        ax.axis("off")

        wrapped_cols = ["\n".join(wrap(str(c), 24)) for c in df.columns]
        df_to_show = df.copy()
        df_to_show.columns = wrapped_cols

        tbl = ax.table(
            cellText=df_to_show.round(4).values,
            rowLabels=df_to_show.index if df_to_show.index.name is not None or not isinstance(df_to_show.index, pd.RangeIndex) else None,
            colLabels=df_to_show.columns,
            cellLoc="center",
            rowLoc="center",
            loc="upper left",
        )
        tbl.auto_set_font_size(False)
        tbl.set_fontsize(10)
        tbl.scale(1.05, 1.2)
        for key, cell in tbl.get_celld().items():
            cell.set_edgecolor("black")
            if key[0] == 0:
                cell.set_linewidth(1.2)
                cell.set_facecolor("lightgray")

        ax.set_title(title, fontsize=12, pad=10, loc="left")
        fig.tight_layout()
        save_path = self.output_dir / filename
        fig.savefig(save_path, dpi=300, bbox_inches="tight")
        plt.close(fig)

        # Persist CSV/Markdown alongside the PNG
        df.to_csv(self.output_dir / (filename.replace(".png", ".csv")), index=True)
        df.to_markdown(self.output_dir / (filename.replace(".png", ".md")))

    # ---------- Step 1: sampling ----------
    def _sample_uniform(self, low: float, high: float, size: int) -> np.ndarray:
        return self.rng.uniform(low, high, size=size)

    def _sample_inputs(self) -> None:
        self.samples = {
            name: self._sample_uniform(low, high, self.n)
            for name, (low, high) in self.bounds.items()
        }

    # ---------- Step 2a: bounds sanity check ----------
    def _check_bounds(self) -> pd.DataFrame:
        self._banner(
            "INPUT BOUND CHECK (SANITY)",
            "Confirms sampled min/max values sit within configured low/high bounds for each variable."
        )
        rows = []
        for name, arr in self.samples.items():
            lo, hi = self.bounds[name]
            arr_min, arr_max = float(np.min(arr)), float(np.max(arr))
            ok = (arr_min >= lo - 1e-12) and (arr_max <= hi + 1e-12)
            rows.append({
                "Configured_Low": lo,
                "Configured_High": hi,
                "Sample_Min": arr_min,
                "Sample_Max": arr_max,
                "Within_Bounds": "PASS" if ok else "FAIL",
            })
        df = pd.DataFrame(rows, index=list(self.samples.keys()))
        print(df.to_string())
        self._save_df_png(df, "Input Bound Check", "01_bound_check.png")
        return df

    # ---------- Step 2b: moment-based validation (theory vs simulated) ----------
    def _moment_validation(self, alpha: float = 0.05) -> pd.DataFrame:
        self._banner(
            "INPUT VALIDATION: BENCHMARK VS SIMULATED",
            "This compares theoretical (Uniform bounds) vs simulated mean & std using a z-test for the mean and a chi-square test for the variance."
        )
        z_crit = stats.norm.ppf(1 - alpha / 2)

        rows = []
        for name, arr in self.samples.items():
            a, b = self.bounds[name]
            mu_theo = 0.5 * (a + b)
            sigma_theo = (b - a) / np.sqrt(12)
            mean_sim = float(np.mean(arr))
            std_sim = float(np.std(arr, ddof=1))

            # Mean z-score
            se_mean = sigma_theo / np.sqrt(self.n) if sigma_theo > 0 else np.nan
            z_mean = (mean_sim - mu_theo) / se_mean if se_mean and se_mean > 0 else np.nan
            mean_match = (not np.isnan(z_mean)) and (abs(z_mean) <= z_crit)

            # Variance/SD check via chi-square (large-sample approximation)
            dfree = self.n - 1
            chi_stat = (dfree * (std_sim ** 2)) / (sigma_theo ** 2) if sigma_theo > 0 else np.nan
            chi_lo = stats.chi2.ppf(alpha / 2, dfree)
            chi_hi = stats.chi2.ppf(1 - alpha / 2, dfree)
            std_match = (not np.isnan(chi_stat)) and (chi_lo <= chi_stat <= chi_hi)

            overall = "MATCH" if (mean_match and std_match) else "MISMATCH"
            tag = f" ({self.aliases.get(name, '')})" if name in self.aliases else ""

            print(f"--- {name}{tag} ---")
            print(f"Benchmark bounds: ({a:0.4f}, {b:0.4f})")
            print(f"Theoretical mean ± std: {mu_theo:0.6f} ± {sigma_theo:0.6f}")
            print(f"Simulated   mean ± std: {mean_sim:0.6f} ± {std_sim:0.6f}")
            if not np.isnan(z_mean):
                print(f"Mean z-score: {z_mean:0.2f}")
            else:
                print("Mean z-score: n/a")
            print(f"Mean check: {'MATCH' if mean_match else 'MISMATCH'} | Std check: {'MATCH' if std_match else 'MISMATCH'}")
            print(f"OVERALL RESULT: {overall}\n")

            rows.append({
                "Variable": name,
                "Alias": self.aliases.get(name, ""),
                "Low": a, "High": b,
                "Theoretical_Mean": mu_theo, "Theoretical_SD": sigma_theo,
                "Simulated_Mean": mean_sim, "Simulated_SD": std_sim,
                "Z_Mean": z_mean, "Mean_Check": "MATCH" if mean_match else "MISMATCH",
                "Chi2_Stat": chi_stat, "SD_Check": "MATCH" if std_match else "MISMATCH",
                "Overall": overall,
            })

        df = pd.DataFrame(rows).set_index("Variable")
        compact = df.drop(columns=["Z_Mean", "Chi2_Stat"])
        self._save_df_png(compact, "Input Validation: Benchmark vs Simulated", "01b_input_validation_moments.png")
        return df

    # ---------- Step 3: compute performance ----------
    def _performance(self) -> np.ndarray:
        self._banner(
            "COMPUTE SUPPLY CHAIN PERFORMANCE",
            "Performance = PORS × PORW × (1 - TD) × (1 - QD)."
        )
        pors = self.samples["Perfect Order Rate - Supplier"]
        porw = self.samples["Perfect Order Rate - Automated Warehouse"]
        td = self.samples["Transport delay"]
        qd = self.samples["Quality degradation"]
        perf = pors * porw * (1.0 - td) * (1.0 - qd)
        if (perf.min() < -1e-12) or (perf.max() > 1.0 + 1e-12):
            raise ValueError("Performance outside [0,1]. Check model formulation and inputs.")
        self.performance = perf
        return perf

    def _summarise(self, y: np.ndarray) -> pd.DataFrame:
        self._banner(
            "PERFORMANCE SUMMARY",
            "Summary statistics for simulated outcomes; used for reporting and confidence statements."
        )
        out = {
            "Mean": float(np.mean(y)),
            "StdDev": float(np.std(y, ddof=1)),
            "Min": float(np.min(y)),
            "P05": float(np.percentile(y, 5)),
            "P10": float(np.percentile(y, 10)),
            "P50": float(np.median(y)),
            "P90": float(np.percentile(y, 90)),
            "P95": float(np.percentile(y, 95)),
            "Max": float(np.max(y)),
        }
        df = pd.DataFrame(out, index=["Supply Chain Performance"])
        print(df.to_string())
        self._save_df_png(df, "Performance Summary", "02_performance_summary.png")
        return df

    # ---------- Step 4: CI + target mean check ----------
    def _ci_and_target(self, y: np.ndarray) -> tuple[float, float]:
        self._banner(
            "90% CONFIDENCE STATEMENT",
            "Central 90% interval of simulated outcomes (5th–95th percentiles)."
        )
        ci_low = float(np.percentile(y, 5))
        ci_high = float(np.percentile(y, 95))
        print(f"With 90% confidence, the Supply Chain Performance lies between {ci_low:0.4f} and {ci_high:0.4f}.")
        return ci_low, ci_high

    def _target_check(self, mean_perf: float) -> pd.DataFrame:
        self._banner(
            "TARGET MEAN CHECK",
            f"Compare observed mean to target mean = {self.target_mean:0.2f}."
        )
        delta = mean_perf - self.target_mean
        rel = (delta / self.target_mean) * 100.0
        df = pd.DataFrame({
            "Target_Mean": [self.target_mean],
            "Observed_Mean": [mean_perf],
            "Delta": [delta],
            "Delta_%_of_Target": [rel],
            "Meets_or_Exceeds_Target": ["YES" if mean_perf >= self.target_mean else "NO"],
        }, index=["Mean Performance Check"])
        print(df.to_string())
        self._save_df_png(df, "Target Mean Check", "03_target_mean_check.png")
        return df

    # ---------- Step 5: sensitivity ----------
    def _standardised_betas(self, X: pd.DataFrame, y: pd.Series) -> pd.Series:
        Zx = (X - X.mean()) / X.std(ddof=0)
        zy = (y - y.mean()) / y.std(ddof=0)
        beta, *_ = np.linalg.lstsq(Zx.values, zy.values, rcond=None)
        return pd.Series(beta, index=X.columns)

    def _plot_sensitivity_bars(self, betas: pd.Series) -> None:
        order = betas.abs().sort_values(ascending=True).index
        fig, ax = plt.subplots(figsize=(8, 4))
        ax.barh(order, betas[order].values)
        ax.set_title("Sensitivity (Standardised Betas)")
        ax.set_xlabel("Standardised Coefficient")
        fig.tight_layout()
        fig.savefig(self.output_dir / "05_sensitivity_betas_bar.png", dpi=300, bbox_inches="tight")
        plt.close(fig)

    # ---------- Step 6–7: correlations & visuals ----------
    def _plot_correlation_bar(self, corr: pd.Series) -> None:
        order = corr.abs().sort_values(ascending=True).index
        fig, ax = plt.subplots(figsize=(8, 4))
        ax.barh(order, corr[order].values)
        ax.set_title("Pearson Correlation with Performance")
        ax.set_xlabel("Correlation")
        fig.tight_layout()
        fig.savefig(self.output_dir / "07_corr_with_y_bar.png", dpi=300, bbox_inches="tight")
        plt.close(fig)

    def _plot_corr_heatmap(self, df: pd.DataFrame) -> None:
        corr = df.corr(numeric_only=True)

        fig, ax = plt.subplots(figsize=(7, 6))
        im = ax.imshow(
            corr.values,
            cmap="coolwarm",
            vmin=-1.0,
            vmax=+1.0,
            interpolation="nearest",
            aspect="equal",
        )

        ax.set_xticks(range(len(corr.columns)))
        ax.set_yticks(range(len(corr.index)))
        ax.set_xticklabels(corr.columns, rotation=45, ha="right")
        ax.set_yticklabels(corr.index)

        ax.set_xticks(np.arange(-0.5, len(corr.columns), 1), minor=True)
        ax.set_yticks(np.arange(-0.5, len(corr.index), 1), minor=True)
        ax.grid(which="minor", color="white", linewidth=1)
        ax.tick_params(which="minor", bottom=False, left=False)

        for i in range(corr.shape[0]):
            for j in range(corr.shape[1]):
                val = corr.values[i, j]
                txt_color = "white" if abs(val) >= 0.5 else "black"
                ax.text(j, i, f"{val:0.2f}", ha="center", va="center", fontsize=10, color=txt_color)

        ax.set_title("Correlation Heatmap")
        cbar = fig.colorbar(im, ax=ax)
        cbar.set_ticks([-1, -0.5, 0, 0.5, 1])

        fig.tight_layout()
        fig.savefig(self.output_dir / "09_corr_heatmap.png", dpi=300, bbox_inches="tight")
        plt.close(fig)

    def _plot_input_output_scatter(self, X: pd.DataFrame, y: pd.Series) -> None:
        fig, axes = plt.subplots(2, 2, figsize=(10, 7))
        axes = axes.flatten()
        for ax, col in zip(axes, X.columns):
            ax.scatter(X[col].values, y.values, s=6, alpha=0.5, edgecolors="none")
            ax.set_xlabel(col)
            ax.set_ylabel("Supply Chain Performance")
            ax.set_title(f"{col} vs Performance")
        fig.tight_layout()
        fig.savefig(self.output_dir / "10_input_output_scatter.png", dpi=300, bbox_inches="tight")
        plt.close(fig)

    # ---------- Run snapshot (audit trail) ----------
    def _echo_run_snapshot(self) -> None:
        """Save and print a snapshot of key means; persist CSV and PNG."""
        pors_mean = float(np.mean(self.samples["Perfect Order Rate - Supplier"]))
        porw_mean = float(np.mean(self.samples["Perfect Order Rate - Automated Warehouse"]))
        td_mean   = float(np.mean(self.samples["Transport delay"]))
        qd_mean   = float(np.mean(self.samples["Quality degradation"]))
        scp_mean  = float(np.mean(self.performance)) if self.performance is not None else np.nan

        # 1) Console + CSV (one-line)
        snapshot_row = pd.DataFrame([{
            "timestamp": datetime.now().isoformat(timespec="seconds"),
            "PORS_mean": pors_mean,
            "PORW_mean": porw_mean,
            "TD_mean": td_mean,
            "QD_mean": qd_mean,
            "Supplier_success": pors_mean,         # success = PORS
            "Warehouse_success": porw_mean,        # success = PORW
            "NoDelay_success": 1 - td_mean,        # success = 1 - TD
            "NoDegrade_success": 1 - qd_mean,      # success = 1 - QD
            "SCP_mean": scp_mean,
        }])

        path_csv = self.output_dir / "00_run_snapshot.csv"
        mode = "a" if path_csv.exists() else "w"
        header = not path_csv.exists()
        snapshot_row.to_csv(path_csv, index=False, mode=mode, header=header)

        print("\nRUN SNAPSHOT (means from this simulation):")
        print(snapshot_row.to_string(index=False))
        print(f"Saved snapshot CSV to: {path_csv}")

        # 2) PNG table (tidy format, per-run only)
        tidy = pd.DataFrame(
            {
                "Metric": [
                    "Supplier perfect order rate (PORS) – mean",
                    "Automated warehouse perfect order rate (PORW) – mean",
                    "Transport delay (TD) – mean",
                    "Quality degradation (QD) – mean",
                    "Supplier success (PORS)",
                    "Warehouse success (PORW)",
                    "No delay success (1 − TD)",
                    "No degradation success (1 − QD)",
                    "Supply Chain Performance (SCP) – mean",
                    "Timestamp",
                ],
                "Value": [
                    pors_mean,
                    porw_mean,
                    td_mean,
                    qd_mean,
                    1 - (1 - pors_mean),   # equals pors_mean; duplicated for clarity
                    1 - (1 - porw_mean),   # equals porw_mean
                    1 - td_mean,
                    1 - qd_mean,
                    scp_mean,
                    datetime.now().isoformat(timespec="seconds"),
                ],
            }
        )

        # Make "Metric" the index so the PNG is a neat two-column table
        tidy = tidy.set_index("Metric")
        self._save_df_png(
            tidy,
            title="Run Snapshot (means from this simulation)",
            filename="00_run_snapshot.png",
        )

    # ---------- Orchestration ----------
    def run(self) -> None:
        # 1) Sample
        self._sample_inputs()

        # 2) Input checks
        self._check_bounds()
        self._moment_validation(alpha=0.05)

        # 3) Compute performance & summarise
        perf = self._performance()
        perf_summary = self._summarise(perf)
        ci_low, ci_high = self._ci_and_target(perf)
        self._target_check(perf_summary.loc["Supply Chain Performance", "Mean"])

        # 5) Sensitivity
        self._banner(
            "SENSITIVITY ANALYSIS",
            "Standardised linear coefficients (betas) to rank variable influence on performance."
        )
        X = pd.DataFrame(self.samples)
        y = pd.Series(perf, name="Supply Chain Performance")
        betas = self._standardised_betas(X, y)
        betas_df = betas.to_frame(name="Standardised_Beta")
        print(betas_df.to_string())
        self._save_df_png(betas_df, "Sensitivity (Standardised Betas)", "04_sensitivity_betas_table.png")
        self._plot_sensitivity_bars(betas)

        # 6) Correlation with performance
        self._banner(
            "CORRELATION WITH PERFORMANCE (PEARSON)",
            "Pearson r between each input and performance; sign = direction, magnitude = strength."
        )
        corr_with_y = X.apply(lambda col: stats.pearsonr(col, y)[0])
        corr_df = corr_with_y.to_frame(name="Pearson_Corr_with_Performance")
        print(corr_df.to_string())
        self._save_df_png(corr_df, "Pearson Correlations with Performance", "06_corr_with_y_table.png")
        self._plot_correlation_bar(corr_with_y)

        # 7) Full correlation matrix + heat map + scatter
        self._banner(
            "PAIRWISE CORRELATIONS & HEAT MAP",
            "Matrix of correlations among all variables; heat map shows sign and magnitude."
        )
        full_df = X.copy()
        full_df["Supply Chain Performance"] = y.values
        corr_matrix = full_df.corr(numeric_only=True)
        self._save_df_png(corr_matrix, "Correlation Matrix", "08_corr_matrix_table.png")
        self._plot_corr_heatmap(full_df)
        self._plot_input_output_scatter(X, y)

        # 7b) Snapshot for audit trail (CSV + PNG)
        self._echo_run_snapshot()

        # 8) Persist raw simulations
        self._banner(
            "SAVE RAW SIMULATIONS",
            "Persist full simulated dataset (inputs + output) to CSV for audit and appendix use."
        )
        sim_csv = self.output_dir / "11_raw_simulations.csv"
        full_df.to_csv(sim_csv, index=False)
        print(f"Saved raw simulations to: {sim_csv}")

        # Final echo
        self._banner("FINAL 90% CONFIDENCE STATEMENT")
        print(f"With 90% confidence, the Supply Chain Performance lies between {ci_low:0.4f} and {ci_high:0.4f}.")


# Quick sanity check (helps catch indentation mistakes during edits)
assert hasattr(MonteCarloMCS, "_echo_run_snapshot"), "Method _echo_run_snapshot not found; check indentation."

# ================================
# MAIN (execution)
# ================================
if __name__ == "__main__":
    bounds = {
        "Perfect Order Rate - Supplier": pors_bounds,
        "Perfect Order Rate - Automated Warehouse": porw_bounds,
        "Transport delay": td_bounds,
        "Quality degradation": qd_bounds,
    }

    mcs = MonteCarloMCS(
        n_simulations=n_simulations,
        bounds=bounds,
        target_mean=target_mean,
        output_dir=output_dir,
    )
    mcs.run()

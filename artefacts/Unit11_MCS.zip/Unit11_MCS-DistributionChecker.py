# ================================
# Distributions validator
#
# Optimised for Python version 3.13
# Created by: Miriam Mahabiersing
# ================================

import numpy as np
import pandas as pd
import matplotlib.pyplot as plt
from scipy import stats
from pathlib import Path
from textwrap import wrap

# ================================
# CONFIGURATION SET-UP
# ================================

# Number of samples per variable
n_simulations = 10_000

# Uniform bounds for each variable (as probabilities in [0, 1])
pors_bounds = (0.82, 0.95)  # Perfect Order Rate – Supplier
porw_bounds = (0.92, 0.98)  # Perfect Order Rate – Automated Warehouse
td_bounds   = (0.03, 0.07)  # Transport delay probability
qd_bounds   = (0.05, 0.10)  # Quality degradation probability

# Output folder for plots
output_dir = Path("END-IMAGES")

# Global pandas display so nothing is truncated in console
pd.set_option("display.width", 200)          # allow wide prints
pd.set_option("display.max_columns", None)
pd.set_option("display.max_rows", None)
pd.set_option("display.max_colwidth", None)
pd.set_option("display.expand_frame_repr", False)
pd.set_option("display.float_format", lambda x: f"{x:0.4f}")

# ================================
# DISTRIBUTION CHECKER
# ================================

class DistributionChecker:
    def __init__(self, n_samples: int, bounds: dict, output_dir: Path | str):
        self.n_samples = n_samples  # <- bugfix: use the argument
        self.bounds = bounds
        self.output_dir = Path(output_dir)
        self._validate_bounds()

        # Modern RNG (no seed, as requested)
        self.rng = np.random.default_rng()

        # Create output directory
        self.output_dir.mkdir(parents=True, exist_ok=True)

        # Frozen uniform distributions with correct loc/scale
        self.dists = {
            name: stats.uniform(loc=low, scale=high - low)
            for name, (low, high) in self.bounds.items()
        }

    def _validate_bounds(self):
        for name, (low, high) in self.bounds.items():
            if not (0.0 <= low < high <= 1.0):
                raise ValueError(f"Invalid probability bounds for {name}: {(low, high)}")

    def sample(self):
        return {
            name: dist.rvs(size=self.n_samples, random_state=self.rng)
            for name, dist in self.dists.items()
        }

    @staticmethod
    def _summary_stats(arr):
        return {
            "Mean":   float(np.mean(arr)),
            "StdDev": float(np.std(arr, ddof=1)),
            "Min":    float(np.min(arr)),
            "Median": float(np.median(arr)),
            "P01":    float(np.percentile(arr, 1)),
            "P99":    float(np.percentile(arr, 99)),
            "Max":    float(np.max(arr)),
        }

    # ---------- Pretty printing & saving helpers ----------
    @staticmethod
    def _print_df(df: pd.DataFrame, title: str = ""):
        if title:
            print("\n" + title)
        # to_string avoids mid-line truncation
        print(df.to_string())

    def _save_df_png(self, df: pd.DataFrame, title: str, filename: str):
        """
        Render a DataFrame as a clean PNG using matplotlib so you can
        insert it directly in the dissertation.
        """
        fig, ax = plt.subplots(figsize=(10, 0.6 + 0.5 * (len(df) + 2)))  # adaptive height
        ax.axis("off")

        # Wrap long column names (if any)
        wrapped_cols = ["\n".join(wrap(str(c), 24)) for c in df.columns]
        df_to_show = df.copy()
        df_to_show.columns = wrapped_cols

        # Build the table
        tbl = ax.table(
            cellText=df_to_show.round(4).values,
            rowLabels=df_to_show.index,
            colLabels=df_to_show.columns,
            cellLoc="center",
            rowLoc="center",
            loc="upper left",
        )

        # Styling
        tbl.auto_set_font_size(False)
        tbl.set_fontsize(10)
        tbl.scale(1.05, 1.2)
        for key, cell in tbl.get_celld().items():
            cell.set_edgecolor("black")
            if key[0] == 0:  # header row
                cell.set_linewidth(1.2)
                cell.set_facecolor("lightgray")

        ax.set_title(title, fontsize=12, pad=10, loc="left")
        fig.tight_layout()
        save_path = self.output_dir / filename
        fig.savefig(save_path, dpi=300, bbox_inches="tight")
        plt.close(fig)
        print(f"Saved table to: {save_path}")

    # ---------- Reports ----------
    def print_summary_table(self, samples):
        rows = [self._summary_stats(v) for v in samples.values()]
        df = pd.DataFrame(rows, index=list(samples.keys()))
        self._print_df(df, title="Input Distribution Summary:")
        # Also save a PNG + CSV/Markdown if you want archival
        self._save_df_png(df, "Input Distribution Summary", "summary_table.png")
        df.to_csv(self.output_dir / "summary_table.csv", index=True)
        df.to_markdown(self.output_dir / "summary_table.md")

    def ks_tests(self, samples, alpha=0.05):
        rows = []
        for name, arr in samples.items():
            ks_stat, p_value = stats.kstest(arr, self.dists[name].cdf)
            rows.append({
                "Variable": name,
                "Dist": "Uniform",
                "KS_stat": ks_stat,
                "p_value": p_value,
                "alpha": alpha,
                "Decision": "ACCEPT" if p_value > alpha else "REJECT"
            })
        df = pd.DataFrame(rows).set_index("Variable")
        # Console (no truncation)
        self._print_df(df, title="KS Goodness-of-Fit Results (samples vs configured Uniform):")
        print("\nInterpretation: If p_value > alpha, we do not reject the specified distribution.")
        # Publication PNG + files
        self._save_df_png(df, "KS Goodness-of-Fit Results", "ks_table.png")
        df.to_csv(self.output_dir / "ks_table.csv", index=True)
        df.to_markdown(self.output_dir / "ks_table.md")

    def plot_histograms(self, samples, bins=30, filename="histograms.png"):
        n = len(samples)
        cols = 2
        rows = (n + cols - 1) // cols
        fig, axes = plt.subplots(rows, cols, figsize=(12, 4 * rows))
        axes = np.atleast_2d(axes)

        for ax, (name, arr) in zip(axes.flat, samples.items()):
            ax.hist(arr, bins=bins, edgecolor="black", alpha=0.85)
            low, high = self.bounds[name]
            ax.set_title(f"{name} ~ Uniform({low:.2f}, {high:.2f})")
            ax.set_xlabel(name)
            ax.set_ylabel("Frequency")

        # Hide any unused axes
        for ax in axes.flat[len(samples):]:
            ax.axis("off")

        fig.tight_layout()
        save_path = self.output_dir / filename
        fig.savefig(save_path, dpi=300, bbox_inches="tight")
        plt.close(fig)
        print(f"Saved histograms to: {save_path}")

    def plot_qq(self, samples, filename="qqplots.png"):
        n = len(samples)
        cols = 2
        rows = (n + cols - 1) // cols
        fig, axes = plt.subplots(rows, cols, figsize=(12, 4 * rows))
        axes = np.atleast_2d(axes)

        for ax, (name, arr) in zip(axes.flat, samples.items()):
            low, high = self.bounds[name]
            stats.probplot(arr, dist="uniform", sparams=(low, high - low), plot=ax)
            ax.set_title(f"Q-Q: {name} vs Uniform(loc={low:.2f}, scale={(high - low):.2f})")

        for ax in axes.flat[len(samples):]:
            ax.axis("off")

        fig.tight_layout()
        save_path = self.output_dir / filename
        fig.savefig(save_path, dpi=300, bbox_inches="tight")
        plt.close(fig)
        print(f"Saved Q-Q plots to: {save_path}")

    def run(self):
        samples = self.sample()
        self.print_summary_table(samples)
        self.ks_tests(samples)
        self.plot_histograms(samples)
        self.plot_qq(samples)


# ================================
# MAIN (execution)
# ================================

if __name__ == "__main__":
    bounds = {
        "Perfect Order Rate - Supplier": pors_bounds,
        "Perfect Order Rate - Automated Warehouse": porw_bounds,
        "Transport delay": td_bounds,
        "Quality degradation": qd_bounds,  # <- removed stray space
    }
    checker = DistributionChecker(n_samples=n_simulations, bounds=bounds, output_dir=output_dir)
    checker.run()

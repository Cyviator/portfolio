"""
Monte Carlo simulation: kale salad 

The demand in pounds for kale salad on Sunday is normally distributed with a mean of 500 and a standard deviation of 100. 
Kale salad costs $3.00 per pound to produce and sells for $8.00 per pound. 
At the end of the day, the leftover kale salad has no value. 
Considering the production levels of 500, 520, 540, 560, 580, and 600 pounds, determine the production quantity that maximizes your expected profit.
  
"""

import numpy as np

#initialisation
mean =   500              # average demand for meatloaf dinners
std =      100            # standard deviation of demand
cost =     3            # cost to produce one dinner
price =      8           # selling price of one dinner

trials =100000          # number of monte carlo simulations


quantity =  np.array([500,520,540,560,580,600])  # production quantities

#simulation
rng = np.random.default_rng()                   
demand = np.maximum(0.0, rng.normal(loc=mean, scale=std, size=trials))     # draws from normal distribution

# compute profit 
Q = quantity[None, :]                             
D = demand[:, None]                                 
sold = np.minimum(D, Q)                             # units actually sold = min(demand, produced)
              
revenue = price * sold                               # calculate revenue
prod_cost = cost * Q                                # calculate production cost 0f Q units


profit = revenue - prod_cost             # calculate profit

# --- summaries ---
mean_profit = profit.mean(axis=0)                 # average profit per Q
best_idx = int(np.argmax(mean_profit))                # index Q with  highest average
best_Q = int(quantity[best_idx])                       # best Q
best_mean = float(mean_profit[best_idx])               # average profit of best Q

print("number of simulations:", trials)
print("Best production quantity:", best_Q)
print("Average profit for best Q:", round(best_mean, 2))
import numpy as np
import matplotlib.pyplot as plt

# Parameters
mean_demand = 200  # Mean demand
std_dev_demand = 30  # Standard deviation of demand
cost_per_car = 25000  # Cost per Envoy
selling_price = 40000  # Selling price per car
discounted_price = 30000  # Discounted price for unsold cars

# Different order quantities to consider
order_quantities = [200, 220, 240, 269, 280, 300]

# Number of simulations
num_simulations = 10000

# Function to run the simulation for a given order quantity
def simulate_profit(order_quantity, mean_demand, std_dev_demand, cost_per_car, selling_price, discounted_price):
    # Generate random demand from a normal distribution
    demand = np.random.normal(mean_demand, std_dev_demand)
    demand = max(0, int(round(demand)))  # Ensure demand is non-negative and an integer

    # Calculate sales and unsold cars
    sold_at_full_price = min(demand, order_quantity)  # Sold at full price (up to demand or ordered quantity)
    unsold_cars = max(0, order_quantity - sold_at_full_price)  # Unsold cars
    sold_at_discount = unsold_cars  # All unsold cars are sold at a discount price

    # Calculate revenue
    revenue = (sold_at_full_price * selling_price) + (sold_at_discount * discounted_price)
    
    # Calculate cost
    cost = order_quantity * cost_per_car
    
    # Calculate profit
    profit = revenue - cost
    
    return profit

# Run the simulation for each order quantity
profits = {quantity: [] for quantity in order_quantities}

for quantity in order_quantities:
    for _ in range(num_simulations):
        profit = simulate_profit(quantity, mean_demand, std_dev_demand, cost_per_car, selling_price, discounted_price)
        profits[quantity].append(profit)

# Calculate the average profit for each order quantity
avg_profits = {quantity: np.mean(profits[quantity]) for quantity in order_quantities}

# Print the average profit for each order quantity
print("Average Profit for each Order Quantity:")
for quantity in order_quantities:
    print(f"Order {quantity}: ${avg_profits[quantity]:,.2f}")

# Plot the average profit for each order quantity
plt.figure(figsize=(10, 6))
plt.bar(avg_profits.keys(), avg_profits.values(), color='skyblue')
plt.xlabel('Order Quantity')
plt.ylabel('Average Profit ($)')
plt.title('Average Profit for Different Order Quantities')
plt.show()

# Determine the optimal order quantity (the one with the highest average profit)
optimal_order_quantity = max(avg_profits, key=avg_profits.get)
print(f"\nOptimal Order Quantity: {optimal_order_quantity} with an Average Profit of ${avg_profits[optimal_order_quantity]:,.2f}")

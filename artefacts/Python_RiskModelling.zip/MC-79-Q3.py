"""
Monte Carlo simulation: Meatloaf dinners 
A supermarket is trying to determine how many meatloaf dinners it should produce on Monday. 

The Monday demand for meatloaf dinners is normally distributed with a mean of 100 and a standard deviation of 20. 
The cost of producing a meatloaf dinner is $2.00, and the dinner sells for $7.00. 
It costs $0.60 at the end of the day to dispose of each unsold dinner. 
If the only possible production quantities are 100, 110, 120, and 130, what production quantity would you recommend?
  
"""

import numpy as np

#initialisation
mean =   100              # average demand for meatloaf dinners
std =      20            # standard deviation of demand
cost =     2             # cost to produce one dinner
price =      7            # selling price of one dinner
disposal_cost=   0.60       # disposal cost per unsold unit
trials =100000          # number of monte carlo simulations


quantity =  np.array([100, 110, 120, 130])  # production quantities

#simulation
rng = np.random.default_rng()                   
demand = np.maximum(0.0, rng.normal(loc=mean, scale=std, size=trials))     # draws from normal distribution

# compute profit 
Q = quantity[None, :]                             # 
D = demand[:, None]                                 
sold = np.minimum(D, Q)                             # units actually sold = min(demand, produced)
leftovers = np.maximum(Q - D, 0.0)                  # unsold units if produced > demand
revenue = price * sold                               # calculate revenue
prod_cost = cost * Q                                # calculate production cost 0f Q units
disp_cost = disposal_cost * leftovers                # calculate disposal cost of leftovers

profit = revenue - prod_cost - disp_cost            # calculate profit

# --- summaries ---
mean_profit = profit.mean(axis=0)                 # average profit per Q
best_idx = int(np.argmax(mean_profit))                # index Q with  highest average
best_Q = int(quantity[best_idx])                       # best Q
best_mean = float(mean_profit[best_idx])               # average profit of best Q

print("number of simulations:", trials)
print("Best production quantity:", best_Q)
print("Average profit for best Q:", round(best_mean, 2))
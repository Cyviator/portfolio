"""
Monte Carlo simulation: Valentine's Day greeting cards 

A greeting-card company is trying to determine how many Valentine’s Day greeting cards to produce. 
The cost of printing x cards is $2 million + 0.70x. For example, printing 1 million cards costs $2.7 million. 
Demand for cards follows a normal random variable with a mean of 2 million and a standard deviation of 400,000. 
The cards are sold for $4.00, and leftover cards have a value of $0.05. 
Among the production quantities of 2.4, 2.6, 2.8, 3, or 3.2 million, which production quantity maximizes the company’s expected profit?
  
"""

import numpy as np

#initialisation
mean =   2000000              # average demand for meatloaf dinners
std =      400000            # standard deviation of demand
fixed_cost =     2000000            # fixed cost to produce cards
variable_cost =0.70                   # variable cost per card
price =      4           # selling price of one card
leftover_value = 0.05      # value of one leftover card
trials =100000          # number of monte carlo simulations


quantity =  np.array([2400000,2600000,2800000,3000000,3200000])  # production quantities

#simulation
rng = np.random.default_rng()                   
demand = np.maximum(0.0, rng.normal(loc=mean, scale=std, size=trials))     # draws from normal distribution

# compute profit 
Q = quantity[None, :]                             
D = demand[:, None]                                 
sold = np.minimum(D, Q)                             # units actually sold = min(demand, produced)
leftovers = np.maximum(Q - D, 0.0)                  # value leftover cards

costs = fixed_cost + variable_cost * Q              # total production costs
revenue = price * sold                               # calculate revenue
salvage= leftover_value *leftovers


profit = revenue + salvage- costs         # calculate profit

# --- summaries ---
mean_profit = profit.mean(axis=0)                 # average profit per Q
best_idx = int(np.argmax(mean_profit))                # index Q with  highest average
best_Q = int(quantity[best_idx])                       # best Q
best_mean = float(mean_profit[best_idx])               # average profit of best Q

print("number of simulations:", trials)
print("Best production quantity:", best_Q)
print("Average profit for best Q:", round(best_mean, 2))
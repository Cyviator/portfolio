"""
Monte Carlo simulation: People Magazine

2.	A small supermarket is trying to determine how many copies of People magazine it should order each week. 
The owner believes the demand for People is governed by the following discrete random variable:
Demand	Probability
15	0.10
20	0.20
25	0.30
30	0.25
35	0.15


3.	The supermarket pays $1.00 for each copy of People and assumes a copy sells at the store for $1.95. 
Each unsold copy can be returned for $0.50. 

How many copies of People should the store order?

  
"""

import numpy as np

#initialisation

demand_values = np.array([15, 20, 25, 30, 35])
probabilities = np.array([0.10, 0.20, 0.30, 0.25, 0.15])


cost =     1             # cost of one People magazine
price =      1.95            # selling price of one People magazine
return_value=   0.50       # return of unsold copy
trials =100000          # number of monte carlo simulations
quantities = demand_values



#simulation of demand
rng = np.random.default_rng()                   
demand = rng.choice(demand_values, size=trials, p=probabilities)

# compute profit 

profits = []
mean_profits = []

for Q in quantities:
    sold = np.minimum(demand, Q)
    leftovers = np.maximum(Q - demand, 0)
    
    revenue = price * sold
    salvage = return_value * leftovers
    cost_total = cost * Q
    
    profit = revenue + salvage - cost_total
    profits.append(profit)
    mean_profits.append(profit.mean())



# pick best quantity Q
mean_profits = np.array(mean_profits)
best_idx = int(np.argmax(mean_profits))
best_Q = int(quantities[best_idx])
best_profit = float(mean_profits[best_idx])

#Summaries

print("Number of simulations:", trials)
print("Order quantities:", quantities)
print("Expected profit per quantity:", np.round(mean_profits, 2))
print("\nBest order quantity:", best_Q)
print("Expected profit for best Q:", round(best_profit, 2))
"""
Monte Carlo simulation:  croissants 

The Monday demand for almond croissants is normally distributed with a mean of 100 and a standard deviation of 25. 
It costs $1.00 to produce a croissant, which sells for $4.00. Leftover croissants must be disposed of at a cost of $0.40 each. 
The bakery is considering producing 80, 100, 120, or 140 croissants. 

Use a Monte Carlo simulation to determine the order quantity that maximizes the bakery’s expected profit.
  
"""

import numpy as np

#initialisation
mean =   100              # average demand 
std =      25            # standard deviation of demand
cost =     1             # cost to produce one croissant
price =      4            # selling price of one croissant
disposal_cost=   0.40       # disposal cost per unsold croissants
trials =100000          # number of monte carlo simulations


quantity =  np.array([80, 100, 120, 140])  # production quantities

#simulation
rng = np.random.default_rng()                   
demand = np.maximum(0.0, rng.normal(loc=mean, scale=std, size=trials))     # draws from normal distribution

# compute profit 
Q = quantity[None, :]                             # 
D = demand[:, None]                                 
sold = np.minimum(D, Q)                             # units actually sold = min(demand, produced)
leftovers = np.maximum(Q - D, 0.0)                  # unsold units if produced > demand
revenue = price * sold                               # calculate revenue
prod_cost = cost * Q                                # calculate production cost 0f Q units
disp_cost = disposal_cost * leftovers                # calculate disposal cost of disposal

profit = revenue - prod_cost - disp_cost            # calculate profit

# --- summaries ---
mean_profit = profit.mean(axis=0)                 # average profit per Q
best_idx = int(np.argmax(mean_profit))                # index Q with  highest average
best_Q = int(quantity[best_idx])                       # best Q
best_mean = float(mean_profit[best_idx])               # average profit of best Q

print("number of simulations:", trials)
print("Best order quantity:", best_Q)
print("Average profit for best Q:", round(best_mean, 2))